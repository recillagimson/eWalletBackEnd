<?php


namespace App\Models\SOAP\GetListOfBanks;


class GetListOfBanks
{
    public string $username;
    public string $password;
}
