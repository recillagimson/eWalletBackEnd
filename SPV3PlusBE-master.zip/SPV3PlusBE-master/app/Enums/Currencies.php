<?php


namespace App\Enums;


class Currencies
{
    const philippinePeso = '0ed266c1-9131-11eb-b44f-1c1b0d14e211';
}
