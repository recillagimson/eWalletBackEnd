<?php

namespace App\Enums;

class Roles
{
    const admin = '6ea33667-1326-4a20-9df6-abe6c9a00df5';
    const client = '26b07613-3901-4daa-ac20-9a46718c2ae7';
    const kyc = 'ac9a207b-ff81-4041-b73a-c41845ef2c95';
    const compliance = 'adf550ab-136e-43ba-8412-0cdc658d3aee';
}
