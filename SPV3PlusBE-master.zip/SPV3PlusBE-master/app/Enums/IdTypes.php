<?php


namespace App\Enums;


class IdTypes
{
    const tin = "0edb4f9f-9131-11eb-b44f-1c1b0d14e211";
    const sss = "0edb77ef-9131-11eb-b44f-1c1b0d14e211";
    const umid = "0edb787d-9131-11eb-b44f-1c1b0d14e211";
    const drivers = "0edb7b31-9131-11eb-b44f-1c1b0d14e211";
}
