<?php


namespace App\Enums;


class TempUserDetailStatuses
{
    const pending = 'PENDING';
    const approved = 'APPROVED';
    const denied = 'DECLINED';

}
