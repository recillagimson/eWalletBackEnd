<?php


namespace App\Enums;


class MaritalStatus
{
    const Single = '0ec5afee-9131-11eb-b44f-1c1b0d14e211';
}
