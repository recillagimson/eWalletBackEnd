<?php

namespace App\Enums;

class SendMoneyConfig
{
    const RefHeader = 'SM';
    
    const ServiceFee = 0.00;
    const CXSEND = '1a86b905-929a-11eb-9663-1c1b0d14e211';
    const CXRECEIVE = 'b1792f37-929c-11eb-9663-1c1b0d14e211';
}
