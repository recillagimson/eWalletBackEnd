<?php

namespace App\Enums;

class NetworkTypes
{
    const Globe = 'GLOBE';
    const Smart = 'SMART';
    const Sun = 'SUN';
}
