<?php

namespace App\Enums;

class DisbursementConfig
{
    const DI = '65742462-fb3e-11eb-9a03-0242ac130003';
    const DO = '65742462-fb6e-11eb-9a03-0242ac130003';
}
