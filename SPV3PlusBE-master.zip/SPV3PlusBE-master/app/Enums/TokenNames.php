<?php

namespace App\Enums;

class TokenNames {
    public const clientToken = "client_token";
    public const userWebToken = "user_web_token";
    public const userMobileToken = "user_mobile_token";
}
