<?php


namespace App\Enums;


class SecBankPesonetStatus
{
    const success = 'SUCCESS';
    const reject = 'REJECT';
    const pending = 'PENDING';
    const SUSPECT = 'SUSPECT';
}
