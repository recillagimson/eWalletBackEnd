<?php


namespace App\Enums;


class BPI
{
    const serviceFee = 0;
}
