<?php

namespace App\Enums;

class AddMoneyProviders
{
    const DragonPay = 'DragonPay';
}
