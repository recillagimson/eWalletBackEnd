<?php


namespace App\Enums;


class TopupTypes
{
    const load = 'load';
    const epins = 'epins';
    const atm_epin = 'E-PINS';
    const atm_sun_network = 'Sun prepaid';
}
