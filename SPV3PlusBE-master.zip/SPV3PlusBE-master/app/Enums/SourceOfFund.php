<?php


namespace App\Enums;


class SourceOfFund
{
    const farming = '0ed801a5-9131-11eb-b44f-1c1b0d14e211';
}
