<?php


namespace App\Enums;


class AccountTiers
{
    const tier1 = 'c5d5cb3e-a175-11eb-b447-1c1b0d14e211';
    const tier2 = '5e007ec8-a176-11eb-b447-1c1b0d14e211';
}
