<?php

namespace App\Enums;

class ECPayStatusTypes
{
    const Success = 'success';
    const Failure = 'failed';
    const Pending = 'pending';
}
