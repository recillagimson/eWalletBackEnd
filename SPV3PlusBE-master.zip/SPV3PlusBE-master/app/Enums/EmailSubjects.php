<?php

namespace App\Enums;

class EmailSubjects
{
    const farmersBatchUploadNotif = "SquidPay - Farmers Batch Upload Notification";
}
