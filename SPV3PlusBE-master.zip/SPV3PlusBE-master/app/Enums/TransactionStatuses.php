<?php


namespace App\Enums;


class TransactionStatuses
{
    const pending = 'PENDING';
    const success = 'SUCCESS';
    const failed = 'FAILED';
}
