<?php


namespace App\Enums;


class Country
{
    const PH = '0eceb736-9131-11eb-b44f-1c1b0d14e211';
}
