<?php

namespace App\Enums;

class PayloadTypes
{
    const Request = 'request';
    const Response = 'response';
}
