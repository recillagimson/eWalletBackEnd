<?php


namespace App\Enums;


class Nationality
{
    const filipino = '700217f7-91b1-11eb-8d33-1c1b0d14e211';
}
