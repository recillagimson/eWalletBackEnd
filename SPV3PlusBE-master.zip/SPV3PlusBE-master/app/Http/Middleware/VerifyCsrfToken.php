<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        'http://mysquidpay.com/spv3plusbe/public/*',
        'https://devsite-fe.squidph.com/*',
        'http://localhost:3000/*',
        'https://localhost:3000/*',
    ];
}
