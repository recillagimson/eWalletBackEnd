<?php

namespace App\Exports\FarmerV2;

use Maatwebsite\Excel\Concerns\FromCollection;

class FarmerSubsidyImport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
