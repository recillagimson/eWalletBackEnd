<?php

namespace App\Repositories\HelpCenter;

use App\Repositories\IRepository;

interface IHelpCenterRepository extends IRepository
{

}
