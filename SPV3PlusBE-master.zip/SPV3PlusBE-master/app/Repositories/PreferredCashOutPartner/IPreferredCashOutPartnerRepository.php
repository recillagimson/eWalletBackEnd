<?php

namespace App\Repositories\PreferredCashOutPartner;

use App\Repositories\IRepository;

interface IPreferredCashOutPartnerRepository extends IRepository
{
    // public function getIdType($is_primary = 1);
    // public function IdTypeForFarmers();
}
