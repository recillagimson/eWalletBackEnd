<?php
namespace App\Repositories\Disbursement;

use App\Repositories\IRepository;

interface IInDisbursementDbpRepository extends IRepository
{

}