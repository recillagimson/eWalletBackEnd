<?php

namespace App\Repositories\NewsAndUpdate;

use App\Repositories\IRepository;

interface INewsAndUpdateRepository extends IRepository
{

}
