<?php

namespace App\Repositories\UserUtilities\Currency;

use App\Repositories\IRepository;

interface ICurrencyRepository extends IRepository
{
    
}
