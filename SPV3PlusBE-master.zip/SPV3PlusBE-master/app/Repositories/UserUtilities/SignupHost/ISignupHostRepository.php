<?php

namespace App\Repositories\UserUtilities\SignupHost;

use App\Repositories\IRepository;

interface ISignupHostRepository extends IRepository
{
    
}
