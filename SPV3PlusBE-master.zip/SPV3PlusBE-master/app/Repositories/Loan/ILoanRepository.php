<?php

namespace App\Repositories\Loan;

use App\Repositories\IRepository;

interface ILoanRepository extends IRepository
{

}
