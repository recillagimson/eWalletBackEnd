<?php

namespace App\Repositories\Payload;

use App\Repositories\IRepository;

interface IPayloadRepository extends IRepository
{

}
