create view billers_report as
select `b`.`account_number`                                       AS `account_number`,
       `c`.`last_name`                                            AS `last_name`,
       `c`.`first_name`                                           AS `first_name`,
       `c`.`middle_name`                                          AS `middle_name`,
       `a`.`reference_number`                                     AS `reference_number`,
       date_format(`a`.`transaction_date`, '%Y-%m-%dT%T%.00000Z') AS `transaction_date`,
       `a`.`transaction_date`                                     AS `original_transaction_date`,
       `a`.`billers_name`                                         AS `billers_name`,
       `a`.`total_amount`                                         AS `total_amount`,
       `a`.`status`                                               AS `status`,
       `a`.`biller_reference_number`                              AS `biller_reference_number`
from ((`spv3plus_staging`.`out_pay_bills` `a` left join `spv3plus_staging`.`user_accounts` `b` on ((`b`.`id` = `a`.`user_account_id`)))
         left join `spv3plus_staging`.`user_details` `c` on ((`a`.`user_account_id` = `c`.`user_account_id`)))
order by `a`.`transaction_date`;

