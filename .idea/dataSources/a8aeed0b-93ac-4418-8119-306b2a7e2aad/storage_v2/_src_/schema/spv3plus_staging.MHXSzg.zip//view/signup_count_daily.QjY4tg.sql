create view signup_count_daily as
select count(`spv3plus_staging`.`user_accounts`.`id`)                                    AS `count`,
       cast((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour) as date) AS `date`
from `spv3plus_staging`.`user_accounts`
where ((`spv3plus_staging`.`user_accounts`.`is_admin` <> 1) and (`spv3plus_staging`.`user_accounts`.`verified` = 1))
group by cast((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour) as date)
order by cast((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour) as date) desc;

