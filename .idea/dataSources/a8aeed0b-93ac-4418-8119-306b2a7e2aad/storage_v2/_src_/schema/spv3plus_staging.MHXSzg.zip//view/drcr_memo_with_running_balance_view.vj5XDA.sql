create view drcr_memo_with_running_balance_view as
select `spv3plus_staging`.`a`.`transaction_date`                                                                                     AS `transaction_date`,
       `spv3plus_staging`.`a`.`original_transaction_date`                                                                            AS `original_transaction_date`,
       `spv3plus_staging`.`a`.`user_account_id`                                                                                      AS `user_account_id`,
       `spv3plus_staging`.`a`.`account_number`                                                                                       AS `account_number`,
       `c`.`first_name`                                                                                                              AS `first_name`,
       `c`.`last_name`                                                                                                               AS `last_name`,
       `c`.`middle_name`                                                                                                             AS `middle_name`,
       `spv3plus_staging`.`a`.`total_amount`                                                                                         AS `total_amount`,
       `spv3plus_staging`.`a`.`status`                                                                                               AS `status`,
       if((`b`.`transaction_type` = 'POSITIVE'), 'CR', 'DR')                                                                         AS `transaction_type`,
       `d`.`category`                                                                                                                AS `category`,
       `d`.`description`                                                                                                             AS `description`,
       `d`.`remarks`                                                                                                                 AS `remarks`,
       `spv3plus_staging`.`a`.`reference_number`                                                                                     AS `reference_number`,
       `b`.`name`                                                                                                                    AS `name`,
       `d`.`user_created`                                                                                                            AS `user_created`,
       concat(left(`e`.`first_name`, 1), '. ', `e`.`last_name`)                                                                      AS `user_created_name`,
       concat(left(`f`.`first_name`, 1), '. ', `f`.`last_name`)                                                                      AS `approved_by_name`,
       concat(left(`g`.`first_name`, 1), '. ', `g`.`last_name`)                                                                      AS `declined_by_name`,
       date_format(`d`.`created_at`, '%Y-%m-%dT%T%.00000Z')                                                                          AS `transaction_date_for_fe`,
       `d`.`approved_at`                                                                                                             AS `approved_at`,
       date_format(`d`.`approved_at`, '%Y-%m-%dT%T%.00000Z')                                                                         AS `approved_at_for_fe`,
       `d`.`declined_at`                                                                                                             AS `declined_at`,
       date_format(`d`.`declined_at`, '%Y-%m-%dT%T%.00000Z')                                                                         AS `declined_at_for_fe`,
       sum((case
                when ((`b`.`transaction_type` = 'POSITIVE') and
                      ((`spv3plus_staging`.`a`.`status` = 'APPROVED') or (`spv3plus_staging`.`a`.`status` = 'SUCCESS')))
                    then `spv3plus_staging`.`a`.`total_amount`
                when ((`b`.`transaction_type` = 'NEGATIVE') and (`spv3plus_staging`.`a`.`status` = 'PENDING') and
                      (`b`.`description` = 'Debit Memo for Adjustment or Commission'))
                    then (`spv3plus_staging`.`a`.`total_amount` * -(1))
                when ((`b`.`transaction_type` = 'NEGATIVE') and
                      ((`spv3plus_staging`.`a`.`status` = 'APPROVED') or (`spv3plus_staging`.`a`.`status` = 'SUCCESS')))
                    then (`spv3plus_staging`.`a`.`total_amount` * -(1))
                else 0 end))
           OVER (PARTITION BY `spv3plus_staging`.`a`.`user_account_id` ORDER BY `spv3plus_staging`.`a`.`original_transaction_date` ) AS `current_balance`,
       sum((case
                when ((`b`.`transaction_type` = 'POSITIVE') and
                      ((`spv3plus_staging`.`a`.`status` = 'APPROVED') or (`spv3plus_staging`.`a`.`status` = 'SUCCESS')))
                    then `spv3plus_staging`.`a`.`total_amount`
                when ((`b`.`transaction_type` = 'NEGATIVE') and
                      ((`spv3plus_staging`.`a`.`status` = 'APPROVED') or (`spv3plus_staging`.`a`.`status` = 'SUCCESS')))
                    then (`spv3plus_staging`.`a`.`total_amount` * -(1))
                else 0 end))
           OVER (PARTITION BY `spv3plus_staging`.`a`.`user_account_id` ORDER BY `spv3plus_staging`.`a`.`original_transaction_date` ) AS `available_balance`
from ((((((`spv3plus_staging`.`transaction_hitories_view` `a` left join `spv3plus_staging`.`transaction_categories` `b` on ((`spv3plus_staging`.`a`.`transaction_category_id` = `b`.`id`))) left join `spv3plus_staging`.`user_details` `c` on ((`c`.`user_account_id` = `spv3plus_staging`.`a`.`user_account_id`))) left join `spv3plus_staging`.`drcr_memos` `d` on ((`d`.`reference_number` = `spv3plus_staging`.`a`.`reference_number`))) left join `spv3plus_staging`.`user_details` `e` on ((`e`.`user_account_id` = `d`.`user_created`))) left join `spv3plus_staging`.`user_details` `f` on ((`f`.`user_account_id` = `d`.`approved_by`)))
         left join `spv3plus_staging`.`user_details` `g` on ((`g`.`user_account_id` = `d`.`declined_by`)))
order by `spv3plus_staging`.`a`.`original_transaction_date` desc;

