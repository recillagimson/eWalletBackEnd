create view running_balance as
select date_format(`a`.`transaction_date`, '%Y-%m-%dT%T%.00000Z')  AS `transaction_date`,
       `a`.`transaction_date`                                      AS `original_transaction_date`,
       `c`.`account_number`                                        AS `account_number`,
       `a`.`user_Account_id`                                       AS `user_Account_id`,
       `b`.`last_name`                                             AS `last_name`,
       `b`.`first_name`                                            AS `first_name`,
       `b`.`middle_name`                                           AS `middle_name`,
       `a`.`total_amount`                                          AS `total_amount`,
       `a`.`reference_number`                                      AS `reference_number`,
       `a`.`status`                                                AS `Status`,
       `a`.`Type`                                                  AS `Type`,
       `c`.`rsbsa_number`                                          AS `rsbsa_number`,
       if((`d`.`title` is null), 'Beginning Balance', `d`.`title`) AS `Description`,
       `a`.`provider_reference`                                    AS `provider_reference`,
       `a`.`transaction_category_id`                               AS `transaction_category_id`,
       `d`.`name`                                                  AS `category`,
       `d`.`title`                                                 AS `category_description`
from ((((select `spv3plus_staging`.`in_add_money_from_bank`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`in_add_money_from_bank`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`in_add_money_from_bank`.`total_amount`            AS `total_amount`,
                `spv3plus_staging`.`in_add_money_from_bank`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`in_add_money_from_bank`.`status`                  AS `status`,
                'CR'                                                                  AS `Type`,
                `spv3plus_staging`.`in_add_money_from_bank`.`transaction_category_id` AS `transaction_category_id`,
                `spv3plus_staging`.`in_add_money_from_bank`.`dragonpay_reference`     AS `provider_reference`
         from `spv3plus_staging`.`in_add_money_from_bank`
         union
         select `spv3plus_staging`.`in_receive_money`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`in_receive_money`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`in_receive_money`.`amount`                  AS `amount`,
                `spv3plus_staging`.`in_receive_money`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`in_receive_money`.`status`                  AS `status`,
                'CR'                                                            AS `Type`,
                `spv3plus_staging`.`in_receive_money`.`transaction_category_id` AS `transaction_category_id`,
                NULL                                                            AS `provider_reference`
         from `spv3plus_staging`.`in_receive_money`
         union
         select `spv3plus_staging`.`in_add_money_bpi`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`in_add_money_bpi`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`in_add_money_bpi`.`amount`                  AS `amount`,
                `spv3plus_staging`.`in_add_money_bpi`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`in_add_money_bpi`.`status`                  AS `status`,
                'CR'                                                            AS `Type`,
                `spv3plus_staging`.`in_add_money_bpi`.`transaction_category_id` AS `transaction_category_id`,
                `spv3plus_staging`.`in_add_money_bpi`.`bpi_reference`           AS `provider_reference`
         from `spv3plus_staging`.`in_add_money_bpi`
         union
         select `spv3plus_staging`.`in_add_money_ubps`.`transaction_date`          AS `transaction_date`,
                `spv3plus_staging`.`in_add_money_ubps`.`user_account_id`           AS `user_Account_id`,
                `spv3plus_staging`.`in_add_money_ubps`.`amount`                    AS `amount`,
                `spv3plus_staging`.`in_add_money_ubps`.`reference_number`          AS `reference_number`,
                `spv3plus_staging`.`in_add_money_ubps`.`status`                    AS `status`,
                'CR'                                                               AS `Type`,
                `spv3plus_staging`.`in_add_money_ubps`.`transaction_category_id`   AS `transaction_category_id`,
                `spv3plus_staging`.`in_add_money_ubps`.`provider_reference_number` AS `provider_reference`
         from `spv3plus_staging`.`in_add_money_ubps`
         union
         select `spv3plus_staging`.`in_add_money_ec_pays`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`in_add_money_ec_pays`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`in_add_money_ec_pays`.`amount`                  AS `amount`,
                `spv3plus_staging`.`in_add_money_ec_pays`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`in_add_money_ec_pays`.`status`                  AS `status`,
                'CR'                                                                AS `Type`,
                `spv3plus_staging`.`in_add_money_ec_pays`.`transction_category_id`  AS `transaction_category_id`,
                `spv3plus_staging`.`in_add_money_ec_pays`.`ec_pay_reference_number` AS `provider_reference`
         from `spv3plus_staging`.`in_add_money_ec_pays`
         union
         select `spv3plus_staging`.`in_disbursement_dbps`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`in_disbursement_dbps`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`in_disbursement_dbps`.`total_amount`            AS `amount`,
                `spv3plus_staging`.`in_disbursement_dbps`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`in_disbursement_dbps`.`status`                  AS `status`,
                'CR'                                                                AS `Type`,
                `spv3plus_staging`.`in_disbursement_dbps`.`transaction_category_id` AS `transaction_category_id`,
                NULL                                                                AS `provider_reference`
         from `spv3plus_staging`.`in_disbursement_dbps`
         union
         select `spv3plus_staging`.`in_receive_from_dbp`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`in_receive_from_dbp`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`in_receive_from_dbp`.`total_amount`            AS `amount`,
                `spv3plus_staging`.`in_receive_from_dbp`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`in_receive_from_dbp`.`status`                  AS `status`,
                'CR'                                                               AS `Type`,
                `spv3plus_staging`.`in_receive_from_dbp`.`transaction_category_id` AS `transaction_category_id`,
                NULL                                                               AS `provider_reference`
         from `spv3plus_staging`.`in_receive_from_dbp`
         union
         select `spv3plus_staging`.`out_buy_loads`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`out_buy_loads`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`out_buy_loads`.`total_amount`            AS `total_amount`,
                `spv3plus_staging`.`out_buy_loads`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`out_buy_loads`.`status`                  AS `status`,
                'DR'                                                         AS `Type`,
                `spv3plus_staging`.`out_buy_loads`.`transaction_category_id` AS `transaction_category_id`,
                `spv3plus_staging`.`out_buy_loads`.`provider_transaction_id` AS `provider_reference`
         from `spv3plus_staging`.`out_buy_loads`
         union
         select `spv3plus_staging`.`out_pay_bills`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`out_pay_bills`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`out_pay_bills`.`total_amount`            AS `total_amount`,
                `spv3plus_staging`.`out_pay_bills`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`out_pay_bills`.`status`                  AS `status`,
                'DR'                                                         AS `Type`,
                `spv3plus_staging`.`out_pay_bills`.`transaction_category_id` AS `transaction_category_id`,
                `spv3plus_staging`.`out_pay_bills`.`biller_reference_number` AS `provider_reference`
         from `spv3plus_staging`.`out_pay_bills`
         union
         select `spv3plus_staging`.`out_send2banks`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`out_send2banks`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`out_send2banks`.`total_amount`            AS `total_amount`,
                `spv3plus_staging`.`out_send2banks`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`out_send2banks`.`status`                  AS `status`,
                'DR'                                                          AS `Type`,
                `spv3plus_staging`.`out_send2banks`.`transaction_category_id` AS `transaction_category_id`,
                `spv3plus_staging`.`out_send2banks`.`provider_transaction_id` AS `provider_reference`
         from `spv3plus_staging`.`out_send2banks`
         union
         select `spv3plus_staging`.`out_send_money`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`out_send_money`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`out_send_money`.`total_amount`            AS `total_amount`,
                `spv3plus_staging`.`out_send_money`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`out_send_money`.`status`                  AS `status`,
                'DR'                                                          AS `Type`,
                `spv3plus_staging`.`out_send_money`.`transaction_category_id` AS `transaction_category_id`,
                NULL                                                          AS `provider_reference`
         from `spv3plus_staging`.`out_send_money`
         union
         select if((`spv3plus_staging`.`drcr_memos`.`approved_at` = NULL),
                   `spv3plus_staging`.`drcr_memos`.`approved_at`,
                   `spv3plus_staging`.`drcr_memos`.`created_at`)          AS `transaction_date`,
                `spv3plus_staging`.`drcr_memos`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`drcr_memos`.`amount`                  AS `total_amount`,
                `spv3plus_staging`.`drcr_memos`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`drcr_memos`.`status`                  AS `status`,
                `spv3plus_staging`.`drcr_memos`.`type_of_memo`            AS `Type`,
                `spv3plus_staging`.`drcr_memos`.`transaction_category_id` AS `transaction_category_id`,
                NULL                                                      AS `provider_reference`
         from `spv3plus_staging`.`drcr_memos`
         union
         select `spv3plus_staging`.`out_disbursement_dbps`.`transaction_date`        AS `transaction_date`,
                `spv3plus_staging`.`out_disbursement_dbps`.`user_account_id`         AS `user_Account_id`,
                `spv3plus_staging`.`out_disbursement_dbps`.`total_amount`            AS `total_amount`,
                `spv3plus_staging`.`out_disbursement_dbps`.`reference_number`        AS `reference_number`,
                `spv3plus_staging`.`out_disbursement_dbps`.`status`                  AS `status`,
                'DR'                                                                 AS `Type`,
                `spv3plus_staging`.`out_disbursement_dbps`.`transaction_category_id` AS `transaction_category_id`,
                NULL                                                                 AS `provider_reference`
         from `spv3plus_staging`.`out_disbursement_dbps`) `a` left join `spv3plus_staging`.`user_details` `b` on ((`b`.`user_account_id` = `a`.`user_Account_id`))) left join `spv3plus_staging`.`user_accounts` `c` on ((`a`.`user_Account_id` = `c`.`id`)))
         left join `spv3plus_staging`.`transaction_categories` `d` on ((`d`.`id` = `a`.`transaction_category_id`)))
where ((`b`.`last_name` is not null) and `c`.`account_number` in (select distinct `b`.`account_number`
                                                                  from (`spv3plus_staging`.`user_transaction_histories` `a`
                                                                           left join `spv3plus_staging`.`user_accounts` `b`
                                                                                     on ((`a`.`user_account_id` = `b`.`id`)))))
order by `a`.`transaction_date`;

