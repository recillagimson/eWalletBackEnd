create view signup_count_weekly as
select count(`spv3plus_staging`.`user_accounts`.`id`)                               AS `count`,
       week((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour), 0) AS `week`,
       year((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour))    AS `year`
from `spv3plus_staging`.`user_accounts`
where ((`spv3plus_staging`.`user_accounts`.`is_admin` <> 1) and (`spv3plus_staging`.`user_accounts`.`verified` = 1))
group by week((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour), 0),
         year((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour))
order by week((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour), 0),
         year((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour)) desc;

