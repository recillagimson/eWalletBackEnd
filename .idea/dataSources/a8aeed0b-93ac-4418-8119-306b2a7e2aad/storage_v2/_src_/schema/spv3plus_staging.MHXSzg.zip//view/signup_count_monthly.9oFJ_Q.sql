create view signup_count_monthly as
select count(`spv3plus_staging`.`user_accounts`.`id`)                             AS `count`,
       month((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour)) AS `month`,
       year((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour))  AS `year`
from `spv3plus_staging`.`user_accounts`
where ((`spv3plus_staging`.`user_accounts`.`is_admin` <> 1) and (`spv3plus_staging`.`user_accounts`.`verified` = 1))
group by month((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour)),
         year((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour))
order by month((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour)),
         year((`spv3plus_staging`.`user_accounts`.`created_at` + interval 8 hour)) desc;

