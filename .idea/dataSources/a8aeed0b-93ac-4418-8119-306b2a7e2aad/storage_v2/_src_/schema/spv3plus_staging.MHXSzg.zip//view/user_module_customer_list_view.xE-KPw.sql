create view user_module_customer_list_view as
select `a`.`id`                                                AS `id`,
       `a`.`account_number`                                    AS `account_number`,
       `a`.`email`                                             AS `email`,
       `b`.`first_name`                                        AS `first_name`,
       `b`.`middle_name`                                       AS `middle_name`,
       `b`.`last_name`                                         AS `last_name`,
       `a`.`mobile_number`                                     AS `mobile_number`,
       `a`.`is_active`                                         AS `is_active`,
       `c`.`account_status`                                    AS `account_status`,
       `c`.`tier_class`                                        AS `tier_class`,
       `a`.`created_at`                                        AS `original_created_at`,
       date_format(`a`.`created_at`, '%Y-%m-%dT%T%.00000Z')    AS `created_at`,
       `d`.`approved_date`                                     AS `original_verified_date`,
       date_format(`d`.`approved_date`, '%Y-%m-%dT%T%.00000Z') AS `verified_date`,
       `c`.`name`                                              AS `name`,
       `d`.`tier_approval_id`                                  AS `tier_approval_id`
from (((`spv3plus_staging`.`user_accounts` `a` left join `spv3plus_staging`.`user_details` `b` on ((`b`.`user_account_id` = `a`.`id`))) left join `spv3plus_staging`.`tiers` `c` on ((`a`.`tier_id` = `c`.`id`)))
         left join lateral (select `spv3plus_staging`.`tier_approvals`.`user_account_id` AS `user_account_id`,
                                   `spv3plus_staging`.`tier_approvals`.`approved_date`   AS `approved_date`,
                                   `spv3plus_staging`.`tier_approvals`.`id`              AS `tier_approval_id`
                            from `spv3plus_staging`.`tier_approvals`
                            where ((`spv3plus_staging`.`tier_approvals`.`user_account_id` = `a`.`id`) and
                                   (`spv3plus_staging`.`tier_approvals`.`status` = 'APPROVED'))
                            limit 0,1) `d` on ((1 = 1)))
where ((`a`.`is_admin` <> 1) and (`a`.`is_merchant` <> 1) and (`a`.`is_onboarder` <> 1) and
       (`a`.`rsbsa_number` is null) and (`b`.`last_name` is not null));

