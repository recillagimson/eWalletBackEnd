create view transaction_hitories_view as
select `a`.`user_account_id`                                      AS `user_account_id`,
       `b`.`rsbsa_number`                                         AS `rsbsa_number`,
       `b`.`account_number`                                       AS `account_number`,
       `a`.`transaction_id`                                       AS `transaction_id`,
       `a`.`reference_number`                                     AS `reference_number`,
       `a`.`total_amount`                                         AS `total_amount`,
       `a`.`transaction_category_id`                              AS `transaction_category_id`,
       `a`.`user_updated`                                         AS `user_updated`,
       `a`.`created_at`                                           AS `created_at`,
       `a`.`updated_at`                                           AS `updated_at`,
       `a`.`deleted_at`                                           AS `deleted_at`,
       `a`.`transaction_date`                                     AS `original_transaction_date`,
       date_format(`a`.`transaction_date`, '%Y-%m-%dT%T%.00000Z') AS `transaction_date`,
       `a`.`status`                                               AS `status`,
       `a`.`provider_reference`                                   AS `provider_reference`
from ((select `spv3plus_staging`.`in_add_money_from_bank`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`in_add_money_from_bank`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`in_add_money_from_bank`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`in_add_money_from_bank`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`in_add_money_from_bank`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`in_add_money_from_bank`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`in_add_money_from_bank`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`in_add_money_from_bank`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`in_add_money_from_bank`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`in_add_money_from_bank`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`in_add_money_from_bank`.`status`                  AS `status`,
              `spv3plus_staging`.`in_add_money_from_bank`.`dragonpay_reference`     AS `provider_reference`
       from `spv3plus_staging`.`in_add_money_from_bank`
       where ((`spv3plus_staging`.`in_add_money_from_bank`.`status` = 'Success') or
              (`spv3plus_staging`.`in_add_money_from_bank`.`status` = 'Pending'))
       union
       select `spv3plus_staging`.`in_receive_money`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`in_receive_money`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`in_receive_money`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`in_receive_money`.`amount`                  AS `total_amount`,
              `spv3plus_staging`.`in_receive_money`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`in_receive_money`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`in_receive_money`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`in_receive_money`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`in_receive_money`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`in_receive_money`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`in_receive_money`.`status`                  AS `status`,
              NULL                                                            AS `provider_reference`
       from `spv3plus_staging`.`in_receive_money`
       where ((`spv3plus_staging`.`in_receive_money`.`status` = 'Success') or
              (`spv3plus_staging`.`in_receive_money`.`status` = 'Pending'))
       union
       select `spv3plus_staging`.`out_buy_loads`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`out_buy_loads`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`out_buy_loads`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`out_buy_loads`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`out_buy_loads`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`out_buy_loads`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`out_buy_loads`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`out_buy_loads`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`out_buy_loads`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`out_buy_loads`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`out_buy_loads`.`status`                  AS `status`,
              `spv3plus_staging`.`out_buy_loads`.`provider_transaction_id` AS `provider_reference`
       from `spv3plus_staging`.`out_buy_loads`
       where ((`spv3plus_staging`.`out_buy_loads`.`status` = 'Success') or
              (`spv3plus_staging`.`out_buy_loads`.`status` = 'Pending'))
       union
       select `spv3plus_staging`.`out_pay_bills`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`out_pay_bills`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`out_pay_bills`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`out_pay_bills`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`out_pay_bills`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`out_pay_bills`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`out_pay_bills`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`out_pay_bills`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`out_pay_bills`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`out_pay_bills`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`out_pay_bills`.`status`                  AS `status`,
              `spv3plus_staging`.`out_pay_bills`.`biller_reference_number` AS `provider_reference`
       from `spv3plus_staging`.`out_pay_bills`
       where ((`spv3plus_staging`.`out_pay_bills`.`status` = 'Success') or
              (`spv3plus_staging`.`out_pay_bills`.`status` = 'Pending'))
       union
       select `spv3plus_staging`.`out_send2banks`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`out_send2banks`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`out_send2banks`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`out_send2banks`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`out_send2banks`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`out_send2banks`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`out_send2banks`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`out_send2banks`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`out_send2banks`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`out_send2banks`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`out_send2banks`.`status`                  AS `status`,
              `spv3plus_staging`.`out_send2banks`.`provider_transaction_id` AS `provider_reference`
       from `spv3plus_staging`.`out_send2banks`
       where ((`spv3plus_staging`.`out_send2banks`.`status` = 'Success') or
              (`spv3plus_staging`.`out_send2banks`.`status` = 'Pending'))
       union
       select `spv3plus_staging`.`out_send_money`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`out_send_money`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`out_send_money`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`out_send_money`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`out_send_money`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`out_send_money`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`out_send_money`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`out_send_money`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`out_send_money`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`out_send_money`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`out_send_money`.`status`                  AS `status`,
              NULL                                                          AS `provider_reference`
       from `spv3plus_staging`.`out_send_money`
       where ((`spv3plus_staging`.`out_send_money`.`status` = 'Success') or
              (`spv3plus_staging`.`out_send_money`.`status` = 'Pending'))
       union
       select `spv3plus_staging`.`drcr_memos`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`drcr_memos`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`drcr_memos`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`drcr_memos`.`amount`                  AS `total_amount`,
              `spv3plus_staging`.`drcr_memos`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`drcr_memos`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`drcr_memos`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`drcr_memos`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`drcr_memos`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`drcr_memos`.`created_at`              AS `transaction_date`,
              `spv3plus_staging`.`drcr_memos`.`status`                  AS `status`,
              NULL                                                      AS `provider_reference`
       from `spv3plus_staging`.`drcr_memos`
       where ((`spv3plus_staging`.`drcr_memos`.`status` = 'APPROVED') or
              (`spv3plus_staging`.`drcr_memos`.`status` = 'PENDING'))
       union
       select `spv3plus_staging`.`out_disbursement_dbps`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`out_disbursement_dbps`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`out_disbursement_dbps`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`out_disbursement_dbps`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`out_disbursement_dbps`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`out_disbursement_dbps`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`out_disbursement_dbps`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`out_disbursement_dbps`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`out_disbursement_dbps`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`out_disbursement_dbps`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`out_disbursement_dbps`.`status`                  AS `status`,
              NULL                                                                 AS `provider_reference`
       from `spv3plus_staging`.`out_disbursement_dbps`
       where (`spv3plus_staging`.`out_disbursement_dbps`.`status` = 'Success')
       union
       select `spv3plus_staging`.`in_receive_from_dbp`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`in_receive_from_dbp`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`in_receive_from_dbp`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`in_receive_from_dbp`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`in_receive_from_dbp`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`in_receive_from_dbp`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`in_receive_from_dbp`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`in_receive_from_dbp`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`in_receive_from_dbp`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`in_receive_from_dbp`.`transaction_date`        AS `transaction_date`,
              `spv3plus_staging`.`in_receive_from_dbp`.`status`                  AS `status`,
              NULL                                                               AS `provider_reference`
       from `spv3plus_staging`.`in_receive_from_dbp`
       where (`spv3plus_staging`.`in_receive_from_dbp`.`status` = 'Success')
       union
       select `spv3plus_staging`.`in_receive_from_dbp`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`in_receive_from_dbp`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`in_receive_from_dbp`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`in_receive_from_dbp`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`in_receive_from_dbp`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`in_receive_from_dbp`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`in_receive_from_dbp`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`in_receive_from_dbp`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`in_receive_from_dbp`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`in_receive_from_dbp`.`transaction_date`        AS `transaction_date`,
              upper(`spv3plus_staging`.`in_receive_from_dbp`.`status`)           AS `status`,
              NULL                                                               AS `provider_reference`
       from `spv3plus_staging`.`in_receive_from_dbp`
       where (`spv3plus_staging`.`in_receive_from_dbp`.`status` = 'SUCCESS')
       union
       select `spv3plus_staging`.`in_disbursement_dbps`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`in_disbursement_dbps`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`in_disbursement_dbps`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`in_disbursement_dbps`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`in_disbursement_dbps`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`in_disbursement_dbps`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`in_disbursement_dbps`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`in_disbursement_dbps`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`in_disbursement_dbps`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`in_disbursement_dbps`.`transaction_date`        AS `transaction_date`,
              upper(`spv3plus_staging`.`in_disbursement_dbps`.`status`)           AS `status`,
              NULL                                                                AS `provider_reference`
       from `spv3plus_staging`.`in_disbursement_dbps`
       where (`spv3plus_staging`.`in_disbursement_dbps`.`status` = 'SUCCESS')
       union
       select `spv3plus_staging`.`in_add_money_ubps`.`user_account_id`           AS `user_account_id`,
              `spv3plus_staging`.`in_add_money_ubps`.`id`                        AS `transaction_id`,
              `spv3plus_staging`.`in_add_money_ubps`.`reference_number`          AS `reference_number`,
              `spv3plus_staging`.`in_add_money_ubps`.`total_amount`              AS `total_amount`,
              `spv3plus_staging`.`in_add_money_ubps`.`transaction_category_id`   AS `transaction_category_id`,
              `spv3plus_staging`.`in_add_money_ubps`.`user_created`              AS `user_updated`,
              `spv3plus_staging`.`in_add_money_ubps`.`created_at`                AS `created_at`,
              `spv3plus_staging`.`in_add_money_ubps`.`updated_at`                AS `updated_at`,
              `spv3plus_staging`.`in_add_money_ubps`.`deleted_at`                AS `deleted_at`,
              `spv3plus_staging`.`in_add_money_ubps`.`transaction_date`          AS `transaction_date`,
              upper(`spv3plus_staging`.`in_add_money_ubps`.`status`)             AS `status`,
              `spv3plus_staging`.`in_add_money_ubps`.`provider_reference_number` AS `provider_reference`
       from `spv3plus_staging`.`in_add_money_ubps`
       where (`spv3plus_staging`.`in_add_money_ubps`.`status` = 'SUCCESS')
       union
       select `spv3plus_staging`.`in_add_money_ec_pays`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`total_amount`            AS `total_amount`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`transction_category_id`  AS `transaction_category_id`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`transaction_date`        AS `transaction_date`,
              upper(`spv3plus_staging`.`in_add_money_ec_pays`.`status`)           AS `status`,
              `spv3plus_staging`.`in_add_money_ec_pays`.`ec_pay_reference_number` AS `provider_reference`
       from `spv3plus_staging`.`in_add_money_ec_pays`
       where ((`spv3plus_staging`.`in_add_money_ec_pays`.`status` = 'SUCCESS') or
              (`spv3plus_staging`.`in_add_money_ec_pays`.`status` = 'PENDING'))
       union
       select `spv3plus_staging`.`in_add_money_bpi`.`user_account_id`         AS `user_account_id`,
              `spv3plus_staging`.`in_add_money_bpi`.`id`                      AS `transaction_id`,
              `spv3plus_staging`.`in_add_money_bpi`.`reference_number`        AS `reference_number`,
              `spv3plus_staging`.`in_add_money_bpi`.`amount`                  AS `total_amount`,
              `spv3plus_staging`.`in_add_money_bpi`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plus_staging`.`in_add_money_bpi`.`user_created`            AS `user_updated`,
              `spv3plus_staging`.`in_add_money_bpi`.`created_at`              AS `created_at`,
              `spv3plus_staging`.`in_add_money_bpi`.`updated_at`              AS `updated_at`,
              `spv3plus_staging`.`in_add_money_bpi`.`deleted_at`              AS `deleted_at`,
              `spv3plus_staging`.`in_add_money_bpi`.`transaction_date`        AS `transaction_date`,
              upper(`spv3plus_staging`.`in_add_money_bpi`.`status`)           AS `status`,
              `spv3plus_staging`.`in_add_money_bpi`.`bpi_reference`           AS `provider_reference`
       from `spv3plus_staging`.`in_add_money_bpi`
       where ((`spv3plus_staging`.`in_add_money_bpi`.`status` = 'Success') or
              (`spv3plus_staging`.`in_add_money_bpi`.`status` = 'Pending'))) `a`
         left join `spv3plus_staging`.`user_accounts` `b` on ((`a`.`user_account_id` = `b`.`id`)))
order by `a`.`transaction_date` desc;

