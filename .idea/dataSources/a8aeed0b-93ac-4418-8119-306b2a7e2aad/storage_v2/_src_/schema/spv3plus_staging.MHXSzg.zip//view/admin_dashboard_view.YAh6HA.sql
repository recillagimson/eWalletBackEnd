create view admin_dashboard_view as
select (select sum(`spv3plus_staging`.`out_pay_bills`.`amount`)
        from `spv3plus_staging`.`out_pay_bills`
        where (`spv3plus_staging`.`out_pay_bills`.`status` = 'SUCCESS'))                            AS `paybills_amount`,
       (select sum(`spv3plus_staging`.`out_pay_bills`.`other_charges`)
        from `spv3plus_staging`.`out_pay_bills`
        where (`spv3plus_staging`.`out_pay_bills`.`status` = 'SUCCESS'))                            AS `paybills_other_charges`,
       (select sum(`spv3plus_staging`.`out_pay_bills`.`service_fee`)
        from `spv3plus_staging`.`out_pay_bills`
        where (`spv3plus_staging`.`out_pay_bills`.`status` = 'SUCCESS'))                            AS `paybills_service_fee`,
       (select count(`a`.`id`)
        from (`spv3plus_staging`.`user_accounts` `a`
                 left join `spv3plus_staging`.`user_details` `b` on ((`b`.`user_account_id` = `a`.`id`)))
        where ((`a`.`is_admin` <> 1) and (`a`.`is_merchant` <> 1) and (`a`.`is_onboarder` <> 1) and
               (`a`.`rsbsa_number` is null) and (`b`.`last_name` is not null)))                     AS `customer_count`,
       0                                                                                            AS `total_transaction`,
       (select sum(`spv3plus_staging`.`in_add_money_from_bank`.`total_amount`)
        from `spv3plus_staging`.`in_add_money_from_bank`
        where (`spv3plus_staging`.`in_add_money_from_bank`.`status` = 'SUCCESS'))                   AS `total_cashin`,
       0                                                                                            AS `sendmoney_amount`,
       0                                                                                            AS `sendmoney_service_fee`,
       (select sum(`spv3plus_staging`.`user_transaction_histories`.`total_amount`)
        from `spv3plus_staging`.`user_transaction_histories`
        where ((right(`spv3plus_staging`.`user_transaction_histories`.`reference_number`, 1) <> 'F') and
               (`spv3plus_staging`.`user_transaction_histories`.`transaction_category_id` in
                ('0ec43457-9131-11eb-b44f-1c1b0d14e211',
                 'b1792f37-929c-11eb-9663-1c1b0d14e211'))))                                         AS `total_collection`,
       (select sum(`spv3plus_staging`.`user_transaction_histories`.`total_amount`)
        from `spv3plus_staging`.`user_transaction_histories`
        where (`spv3plus_staging`.`user_transaction_histories`.`transaction_category_id` in
               ('0ec41025-9131-11eb-b44f-1c1b0d14e211', '0ec432e7-9131-11eb-b44f-1c1b0d14e211',
                'edf4d5d0-9299-11eb-9663-1c1b0d14e211', 'c5b62dbd-95a0-11eb-8473-1c1b0d14e211',
                '1a86b905-929a-11eb-9663-1c1b0d14e211')))                                           AS `total_disbursement`,
       ((select sum(`spv3plus_staging`.`user_transaction_histories`.`total_amount`)
         from `spv3plus_staging`.`user_transaction_histories`
         where ((right(`spv3plus_staging`.`user_transaction_histories`.`reference_number`, 1) <> 'F') and
                (`spv3plus_staging`.`user_transaction_histories`.`transaction_category_id` in
                 ('0ec43457-9131-11eb-b44f-1c1b0d14e211', 'b1792f37-929c-11eb-9663-1c1b0d14e211')))) -
        (select sum(`spv3plus_staging`.`user_transaction_histories`.`total_amount`)
         from `spv3plus_staging`.`user_transaction_histories`
         where (`spv3plus_staging`.`user_transaction_histories`.`transaction_category_id` in
                ('0ec41025-9131-11eb-b44f-1c1b0d14e211', '0ec432e7-9131-11eb-b44f-1c1b0d14e211',
                 'edf4d5d0-9299-11eb-9663-1c1b0d14e211', 'c5b62dbd-95a0-11eb-8473-1c1b0d14e211',
                 '1a86b905-929a-11eb-9663-1c1b0d14e211'))))                                         AS `total_available_funds`;

