create view dbp_issue_imc_details_view as
select concat_ws('-', substr(`a`.`rsbsa_number`, 1, 2), substr(`a`.`rsbsa_number`, 3, 2),
                 substr(`a`.`rsbsa_number`, 5, 2), substr(`a`.`rsbsa_number`, 7, 3),
                 substr(`a`.`rsbsa_number`, 10, 6)) AS `RSBSA REFERENCE NUMBER`,
       `b`.`first_name`                             AS `FIRSTNAME`,
       `b`.`middle_name`                            AS `MIDDLENAME`,
       `b`.`last_name`                              AS `LASTNAME`,
       ifnull(`b`.`name_extension`, '')             AS `EXTENSION NAME`,
       `b`.`id_number`                              AS `ID NUMBER`,
       `b`.`government_id_type`                     AS `GOV ID TYPE`,
       `b`.`house_no_street`                        AS `STREET NUMBER`,
       `b`.`barangay`                               AS `BARANGAY`,
       `b`.`municipality`                           AS `MUNICIPALITY`,
       `b`.`district`                               AS `DISTRICT`,
       `b`.`province_state`                         AS `PROVINCE`,
       `b`.`region`                                 AS `REGION`,
       `b`.`birth_date`                             AS `BIRTH DATE`,
       `b`.`place_of_birth`                         AS `PLACE OF BIRTH`,
       ifnull(`a`.`mobile_number`, '')              AS `MOBILE NUMBER`,
       `b`.`sex`                                    AS `SEX`,
       'FILIPINO'                                   AS `NATIONALITY`,
       'Farmer'                                     AS `PROFESSION`,
       'Farming'                                    AS `SOURCE OF FUNDS`,
       `b`.`mother_maidenname`                      AS `MOTHER MAIDEN NAME`,
       `b`.`no_of_farm_parcel`                      AS `# OF FARM PARCEL`,
       `b`.`total_farm_area`                        AS `TOTAL FARM AREA (Ha)`,
       `a`.`account_number`                         AS `ACCOUNT NUMBER`,
       (case
            when (`a`.`verified` = 1) then cast((`b`.`updated_at` + interval 8 hour) as date)
            else 'IMC Not Issued' end)              AS `REMARKS`
from (`spv3plusdbp`.`user_accounts` `a`
         left join `spv3plusdbp`.`user_details` `b` on ((`b`.`user_account_id` = `a`.`id`)))
where ((left(`a`.`account_number`, 1) = 'F') and (`b`.`region` <> 'NATIONAL CAPITAL REGION'));

