create view dbp_on_boarding_list_view_new as
select `a`.`id`                                                             AS `id`,
       `a`.`account_number`                                                 AS `account_number`,
       `a`.`rsbsa_number`                                                   AS `rsbsa_number`,
       `b`.`first_name`                                                     AS `first_name`,
       `b`.`middle_name`                                                    AS `middle_name`,
       `b`.`last_name`                                                      AS `last_name`,
       `b`.`name_extension`                                                 AS `name_extension`,
       `b`.`birth_date`                                                     AS `birth_date`,
       `b`.`municipality`                                                   AS `city_municipality`,
       `b`.`province_state`                                                 AS `province_state`,
       if((`a`.`verified` = 1), 'VERIFIED', 'UNVERIFIED')                   AS `profile_status`,
       (`a`.`created_at` + interval 8 hour)                                 AS `created_at`,
       if((`a`.`verified` = 1), (`b`.`updated_at` + interval 8 hour), NULL) AS `approved_date`,
       if((`a`.`verified` = 1), 'On-boarding successful', NULL)             AS `remarks`,
       `a`.`created_at`                                                     AS `original_created_at`
from (`spv3plusdbp`.`user_accounts` `a`
         left join `spv3plusdbp`.`user_details` `b` on ((`a`.`id` = `b`.`user_account_id`)))
where (`b`.`region` in ('CORDILLERA ADMINISTRATIVE REGION CAR', 'REGION II CAGAYAN VALLEY', 'REGION III CENTRAL LUZON',
                        'REGION IV-A CALABARZON', 'REGION IV-B MIMAROPA', 'REGION IX ZAMBOANGA PENINSULA',
                        'REGION V BICOL REGION', 'REGION VI', 'REGION VII CENTRAL VISAYAS', 'REGION XI DAVAO REGION',
                        'REGION XII'));

