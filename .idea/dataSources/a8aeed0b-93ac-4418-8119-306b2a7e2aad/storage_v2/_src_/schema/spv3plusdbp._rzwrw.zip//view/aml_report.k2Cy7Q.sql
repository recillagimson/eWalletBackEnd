create view aml_report as
select `a`.`account_number` AS `account_number`,
       `a`.`last_name`      AS `last_name`,
       `a`.`first_name`     AS `first_name`,
       `a`.`middle_name`    AS `middle_name`,
       `a`.`total_amount`   AS `total_amount`
from (select `b`.`account_number`    AS `account_number`,
             `c`.`last_name`         AS `last_name`,
             `c`.`first_name`        AS `first_name`,
             `c`.`middle_name`       AS `middle_name`,
             sum(`a`.`total_amount`) AS `total_amount`
      from ((`spv3plusdbp`.`user_transaction_histories` `a` left join `spv3plusdbp`.`user_accounts` `b` on ((`b`.`id` = `a`.`user_account_id`)))
               left join `spv3plusdbp`.`user_details` `c` on ((`a`.`user_account_id` = `c`.`user_account_id`)))
      group by `b`.`account_number`, `c`.`last_name`, `c`.`first_name`, `c`.`middle_name`
      limit 0,100000) `a`
where (`a`.`total_amount` > 500000);

