create view transaction_hitories_view as
select `a`.`user_account_id`                                      AS `user_account_id`,
       `b`.`rsbsa_number`                                         AS `rsbsa_number`,
       `b`.`account_number`                                       AS `account_number`,
       `a`.`transaction_id`                                       AS `transaction_id`,
       `a`.`reference_number`                                     AS `reference_number`,
       `a`.`total_amount`                                         AS `total_amount`,
       `a`.`transaction_category_id`                              AS `transaction_category_id`,
       `a`.`user_updated`                                         AS `user_updated`,
       `a`.`created_at`                                           AS `created_at`,
       `a`.`updated_at`                                           AS `updated_at`,
       `a`.`deleted_at`                                           AS `deleted_at`,
       `a`.`transaction_date`                                     AS `original_transaction_date`,
       date_format(`a`.`transaction_date`, '%Y-%m-%dT%T%.00000Z') AS `transaction_date`,
       `a`.`status`                                               AS `status`,
       `a`.`provider_reference`                                   AS `provider_reference`
from ((select `spv3plusdbp`.`out_disbursement_dbps`.`user_account_id`         AS `user_account_id`,
              `spv3plusdbp`.`out_disbursement_dbps`.`id`                      AS `transaction_id`,
              `spv3plusdbp`.`out_disbursement_dbps`.`reference_number`        AS `reference_number`,
              `spv3plusdbp`.`out_disbursement_dbps`.`total_amount`            AS `total_amount`,
              `spv3plusdbp`.`out_disbursement_dbps`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plusdbp`.`out_disbursement_dbps`.`user_created`            AS `user_updated`,
              `spv3plusdbp`.`out_disbursement_dbps`.`created_at`              AS `created_at`,
              `spv3plusdbp`.`out_disbursement_dbps`.`updated_at`              AS `updated_at`,
              `spv3plusdbp`.`out_disbursement_dbps`.`deleted_at`              AS `deleted_at`,
              `spv3plusdbp`.`out_disbursement_dbps`.`transaction_date`        AS `transaction_date`,
              `spv3plusdbp`.`out_disbursement_dbps`.`status`                  AS `status`,
              NULL                                                            AS `provider_reference`
       from `spv3plusdbp`.`out_disbursement_dbps`
       where (`spv3plusdbp`.`out_disbursement_dbps`.`status` = 'Success')
       union
       select `spv3plusdbp`.`in_receive_from_dbp`.`user_account_id`         AS `user_account_id`,
              `spv3plusdbp`.`in_receive_from_dbp`.`id`                      AS `transaction_id`,
              `spv3plusdbp`.`in_receive_from_dbp`.`reference_number`        AS `reference_number`,
              `spv3plusdbp`.`in_receive_from_dbp`.`total_amount`            AS `total_amount`,
              `spv3plusdbp`.`in_receive_from_dbp`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plusdbp`.`in_receive_from_dbp`.`user_created`            AS `user_updated`,
              `spv3plusdbp`.`in_receive_from_dbp`.`created_at`              AS `created_at`,
              `spv3plusdbp`.`in_receive_from_dbp`.`updated_at`              AS `updated_at`,
              `spv3plusdbp`.`in_receive_from_dbp`.`deleted_at`              AS `deleted_at`,
              `spv3plusdbp`.`in_receive_from_dbp`.`transaction_date`        AS `transaction_date`,
              `spv3plusdbp`.`in_receive_from_dbp`.`status`                  AS `status`,
              NULL                                                          AS `provider_reference`
       from `spv3plusdbp`.`in_receive_from_dbp`
       where (`spv3plusdbp`.`in_receive_from_dbp`.`status` = 'Success')
       union
       select `spv3plusdbp`.`in_receive_from_dbp`.`user_account_id`         AS `user_account_id`,
              `spv3plusdbp`.`in_receive_from_dbp`.`id`                      AS `transaction_id`,
              `spv3plusdbp`.`in_receive_from_dbp`.`reference_number`        AS `reference_number`,
              `spv3plusdbp`.`in_receive_from_dbp`.`total_amount`            AS `total_amount`,
              `spv3plusdbp`.`in_receive_from_dbp`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plusdbp`.`in_receive_from_dbp`.`user_created`            AS `user_updated`,
              `spv3plusdbp`.`in_receive_from_dbp`.`created_at`              AS `created_at`,
              `spv3plusdbp`.`in_receive_from_dbp`.`updated_at`              AS `updated_at`,
              `spv3plusdbp`.`in_receive_from_dbp`.`deleted_at`              AS `deleted_at`,
              `spv3plusdbp`.`in_receive_from_dbp`.`transaction_date`        AS `transaction_date`,
              upper(`spv3plusdbp`.`in_receive_from_dbp`.`status`)           AS `status`,
              NULL                                                          AS `provider_reference`
       from `spv3plusdbp`.`in_receive_from_dbp`
       where (`spv3plusdbp`.`in_receive_from_dbp`.`status` = 'SUCCESS')
       union
       select `spv3plusdbp`.`in_disbursement_dbps`.`user_account_id`         AS `user_account_id`,
              `spv3plusdbp`.`in_disbursement_dbps`.`id`                      AS `transaction_id`,
              `spv3plusdbp`.`in_disbursement_dbps`.`reference_number`        AS `reference_number`,
              `spv3plusdbp`.`in_disbursement_dbps`.`total_amount`            AS `total_amount`,
              `spv3plusdbp`.`in_disbursement_dbps`.`transaction_category_id` AS `transaction_category_id`,
              `spv3plusdbp`.`in_disbursement_dbps`.`user_created`            AS `user_updated`,
              `spv3plusdbp`.`in_disbursement_dbps`.`created_at`              AS `created_at`,
              `spv3plusdbp`.`in_disbursement_dbps`.`updated_at`              AS `updated_at`,
              `spv3plusdbp`.`in_disbursement_dbps`.`deleted_at`              AS `deleted_at`,
              `spv3plusdbp`.`in_disbursement_dbps`.`transaction_date`        AS `transaction_date`,
              upper(`spv3plusdbp`.`in_disbursement_dbps`.`status`)           AS `status`,
              NULL                                                           AS `provider_reference`
       from `spv3plusdbp`.`in_disbursement_dbps`
       where (`spv3plusdbp`.`in_disbursement_dbps`.`status` = 'SUCCESS')) `a`
         left join `spv3plusdbp`.`user_accounts` `b` on ((`a`.`user_account_id` = `b`.`id`)))
order by `a`.`transaction_date` desc;

