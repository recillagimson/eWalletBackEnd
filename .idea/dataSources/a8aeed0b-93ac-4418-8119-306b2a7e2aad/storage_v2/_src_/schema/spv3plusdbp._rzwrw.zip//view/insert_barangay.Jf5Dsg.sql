create view insert_barangay as
select uuid()                  AS `uuid()`,
       `a`.`barangay`          AS `barangay`,
       `a`.`municipality_code` AS `municipality_code`,
       `a`.`zip_code`          AS `zip_code`
from (select distinct `a`.`province_state`    AS `province_state`,
                      `a`.`city`              AS `city`,
                      `a`.`barangay`          AS `barangay`,
                      `b`.`municipality_code` AS `municipality_code`,
                      `b`.`zip_code`          AS `zip_code`
      from (`spv3plusdbp`.`user_details` `a`
               left join `spv3plusdbp`.`municipalities` `b`
                         on (((`b`.`name` = `a`.`city`) and (left(`b`.`province_code`, 2) = '03'))))
      where ((`a`.`region` = 'REGION III CENTRAL LUZON') and
             `a`.`barangay` in (select `spv3plusdbp`.`barangays`.`name` from `spv3plusdbp`.`barangays`) is false)) `a`
limit 0,1000000;

