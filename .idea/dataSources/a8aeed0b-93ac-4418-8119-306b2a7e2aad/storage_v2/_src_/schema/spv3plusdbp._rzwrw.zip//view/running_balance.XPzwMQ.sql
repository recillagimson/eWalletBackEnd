create view running_balance as
select `b`.`id`                                                                                                            AS `transaction_category_id`,
       `spv3plusdbp`.`a`.`rsbsa_number`                                                                                    AS `rsbsa_number`,
       `spv3plusdbp`.`a`.`transaction_date`                                                                                AS `transaction_date`,
       `spv3plusdbp`.`a`.`original_transaction_date`                                                                       AS `original_transaction_date`,
       `spv3plusdbp`.`a`.`user_account_id`                                                                                 AS `user_account_id`,
       `spv3plusdbp`.`a`.`account_number`                                                                                  AS `account_number`,
       `c`.`first_name`                                                                                                    AS `first_name`,
       `c`.`last_name`                                                                                                     AS `last_name`,
       `c`.`middle_name`                                                                                                   AS `middle_name`,
       `spv3plusdbp`.`a`.`total_amount`                                                                                    AS `total_amount`,
       `spv3plusdbp`.`a`.`status`                                                                                          AS `status`,
       if((`b`.`transaction_type` = 'POSITIVE'), 'CR', 'DR')                                                               AS `type`,
       `b`.`description`                                                                                                   AS `description`,
       `b`.`name`                                                                                                          AS `category`,
       `spv3plusdbp`.`a`.`reference_number`                                                                                AS `reference_number`,
       `b`.`name`                                                                                                          AS `name`,
       sum((case
                when ((`b`.`transaction_type` = 'POSITIVE') and
                      ((`spv3plusdbp`.`a`.`status` = 'APPROVED') or (`spv3plusdbp`.`a`.`status` = 'SUCCESS')))
                    then `spv3plusdbp`.`a`.`total_amount`
                when ((`b`.`transaction_type` = 'NEGATIVE') and (`spv3plusdbp`.`a`.`status` = 'PENDING') and
                      (`b`.`description` = 'Debit Memo for Adjustment or Commission'))
                    then (`spv3plusdbp`.`a`.`total_amount` * -(1))
                when ((`b`.`transaction_type` = 'NEGATIVE') and
                      ((`spv3plusdbp`.`a`.`status` = 'APPROVED') or (`spv3plusdbp`.`a`.`status` = 'SUCCESS')))
                    then (`spv3plusdbp`.`a`.`total_amount` * -(1))
                else 0 end))
           OVER (PARTITION BY `spv3plusdbp`.`a`.`user_account_id` ORDER BY `spv3plusdbp`.`a`.`original_transaction_date` ) AS `current_balance`,
       sum((case
                when ((`b`.`transaction_type` = 'POSITIVE') and
                      ((`spv3plusdbp`.`a`.`status` = 'APPROVED') or (`spv3plusdbp`.`a`.`status` = 'SUCCESS')))
                    then `spv3plusdbp`.`a`.`total_amount`
                when ((`b`.`transaction_type` = 'NEGATIVE') and
                      ((`spv3plusdbp`.`a`.`status` = 'APPROVED') or (`spv3plusdbp`.`a`.`status` = 'SUCCESS')))
                    then (`spv3plusdbp`.`a`.`total_amount` * -(1))
                else 0 end))
           OVER (PARTITION BY `spv3plusdbp`.`a`.`user_account_id` ORDER BY `spv3plusdbp`.`a`.`original_transaction_date` ) AS `available_balance`
from ((`spv3plusdbp`.`transaction_hitories_view` `a` left join `spv3plusdbp`.`transaction_categories` `b` on ((`spv3plusdbp`.`a`.`transaction_category_id` = `b`.`id`)))
         left join `spv3plusdbp`.`user_details` `c` on ((`c`.`user_account_id` = `spv3plusdbp`.`a`.`user_account_id`)))
order by `spv3plusdbp`.`a`.`original_transaction_date` desc;

