create view dbp_issued_imc_view as
select `a`.`on_boarding_date`                  AS `on_boarding_date`,
       `a`.`region`                            AS `region`,
       `a`.`province_state`                    AS `province_state`,
       concat('ONBISSRFFA', `a`.`da_province_code`, 'SPTI',
              convert(date_format(`a`.`on_boarding_date`, '%y%m%d') using utf8mb4),
              convert(lpad(dense_rank() OVER (PARTITION BY `a`.`on_boarding_date` ORDER BY `a`.`region` desc ), 3, 0)
                      using utf8mb4), '.xlsx') AS `success_file`,
       concat('ONBUISSRFFA', `a`.`da_province_code`, 'SPTI',
              convert(date_format(`a`.`on_boarding_date`, '%y%m%d') using utf8mb4),
              convert(lpad(dense_rank() OVER (PARTITION BY `a`.`on_boarding_date` ORDER BY `a`.`region` desc ), 3, 0)
                      using utf8mb4), '.xlsx') AS `failed_file`
from (select cast((`a`.`updated_at` + interval 8 hour) as date) AS `on_boarding_date`,
             `b`.`region`                                       AS `region`,
             `b`.`province_state`                               AS `province_state`,
             `c`.`da_province_code`                             AS `da_province_code`
      from ((`spv3plusdbp`.`user_accounts` `a` left join `spv3plusdbp`.`user_details` `b` on ((`a`.`id` = `b`.`user_account_id`)))
               left join `spv3plusdbp`.`provinces` `c` on ((`b`.`province_state` = `c`.`name`)))
      where ((`a`.`verified` = 1) and (`a`.`rsbsa_number` is not null))
      group by cast((`a`.`updated_at` + interval 8 hour) as date), `b`.`region`, `b`.`province_state`,
               `c`.`da_province_code`
      order by cast((`a`.`updated_at` + interval 8 hour) as date)) `a`
order by `a`.`on_boarding_date` desc;

