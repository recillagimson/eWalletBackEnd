create view dbp_claims_report as
select `a`.`reference_number`                                     AS `reference_number`,
       date_format(`a`.`transaction_date`, '%Y-%m-%dT%T%.00000Z') AS `transaction_date`,
       `a`.`transaction_date`                                     AS `original_transaction_date`,
       `c`.`rsbsa_number`                                         AS `rsbsa_number`,
       `a`.`total_amount`                                         AS `amount_claimed`,
       `d`.`city`                                                 AS `city_municipality`,
       `d`.`province_state`                                       AS `province_state`,
       `d`.`region`                                               AS `region`,
       `f`.`name`                                                 AS `cash_out_partner`
from (((((`spv3plusdbp`.`in_disbursement_dbps` `a` left join `spv3plusdbp`.`out_disbursement_dbps` `b` on ((`b`.`reference_number` = `a`.`out_disbursement_dbps_reference_number`))) left join `spv3plusdbp`.`user_accounts` `c` on ((`b`.`user_account_id` = `c`.`id`))) left join `spv3plusdbp`.`user_details` `d` on ((`d`.`user_account_id` = `b`.`user_account_id`))) left join `spv3plusdbp`.`user_accounts` `e` on ((`a`.`user_account_id` = `e`.`id`)))
         left join `spv3plusdbp`.`merchant_accounts` `f` on ((`e`.`merchant_account_id` = `f`.`id`)))
where (`a`.`reference_number` <> 'DI0003200')
order by date_format(`a`.`transaction_date`, '%Y-%m-%dT%T%.00000Z') desc;

