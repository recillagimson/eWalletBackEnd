create view dbp_customer_list as
select `a`.`rsbsa_number`                                   AS `rsbsa_number`,
       `a`.`account_number`                                 AS `account_number`,
       `b`.`first_name`                                     AS `first_name`,
       `b`.`middle_name`                                    AS `middle_name`,
       `b`.`last_name`                                      AS `last_name`,
       if((`a`.`verified` = 1), 'Active', 'In-active')      AS `account_status`,
       `c`.`account_status`                                 AS `profile_status`,
       `a`.`created_at`                                     AS `original_created_at`,
       date_format(`a`.`created_at`, '%Y-%m-%dT%T%.00000Z') AS `created_at`
from ((`spv3plusdbp`.`user_accounts` `a` left join `spv3plusdbp`.`user_details` `b` on ((`a`.`id` = `b`.`user_account_id`)))
         left join `spv3plusdbp`.`tiers` `c` on ((`a`.`tier_id` = `c`.`id`)))
where (`a`.`rsbsa_number` is not null)
order by date_format(`a`.`created_at`, '%Y-%m-%dT%T%.00000Z') desc;

