create view customer_list_view as
select `a`.`id`                                                  AS `id`,
       `a`.`account_number`                                      AS `account_number`,
       `a`.`rsbsa_number`                                        AS `rsbsa_number`,
       `b`.`first_name`                                          AS `first_name`,
       `b`.`last_name`                                           AS `last_name`,
       `b`.`middle_name`                                         AS `middle_name`,
       `a`.`verified`                                            AS `verified`,
       if((`a`.`verified` = 1), 'Active', 'In-active')           AS `account_status`,
       `c`.`account_status`                                      AS `profile_status`,
       `c`.`tier_class`                                          AS `tier_class`,
       date_format(`b`.`created_at`, '%Y-%m-%dT%T%.00000Z')      AS `created_at`,
       `b`.`created_at`                                          AS `original_created_at`,
       date_format(`d`.`approved_date`, '%Y-%m-%dT%T%.00000Z')   AS `approved_date`,
       `d`.`approved_date`                                       AS `original_approved_date`,
       `a`.`is_admin`                                            AS `is_admin`,
       (case
            when (`e`.`hv_result` is null) then `e`.`hv_result`
            when (`e`.`hv_result` = 'green') then 'On-boarding successful'
            else 'Deduplication detected during onboarding' end) AS `on_boarding_status`
from ((((`spv3plusdbp`.`user_accounts` `a` left join `spv3plusdbp`.`user_details` `b` on ((`a`.`id` = `b`.`user_account_id`))) left join `spv3plusdbp`.`tiers` `c` on ((`a`.`tier_id` = `c`.`id`))) left join lateral (select `spv3plusdbp`.`tier_approvals`.`user_account_id` AS `user_account_id`,
                                                                                                                                                                                                                              `spv3plusdbp`.`tier_approvals`.`approved_date`   AS `approved_date`
                                                                                                                                                                                                                       from `spv3plusdbp`.`tier_approvals`
                                                                                                                                                                                                                       where ((`spv3plusdbp`.`tier_approvals`.`user_account_id` = `a`.`id`) and
                                                                                                                                                                                                                              (`spv3plusdbp`.`tier_approvals`.`status` = 'APPROVED'))
                                                                                                                                                                                                                       limit 0,1) `d` on ((1 = 1)))
         left join lateral (select `spv3plusdbp`.`kyc_verifications`.`user_account_id` AS `user_account_id`,
                                   `spv3plusdbp`.`kyc_verifications`.`hv_result`       AS `hv_result`
                            from `spv3plusdbp`.`kyc_verifications`
                            where ((`spv3plusdbp`.`kyc_verifications`.`user_account_id` = `a`.`id`) and
                                   (`spv3plusdbp`.`kyc_verifications`.`status` = 'CALLBACK_RECEIVED'))
                            order by field(`spv3plusdbp`.`kyc_verifications`.`hv_result`, 'green') desc
                            limit 0,1) `e` on ((1 = 1)))
order by `b`.`created_at` desc;

