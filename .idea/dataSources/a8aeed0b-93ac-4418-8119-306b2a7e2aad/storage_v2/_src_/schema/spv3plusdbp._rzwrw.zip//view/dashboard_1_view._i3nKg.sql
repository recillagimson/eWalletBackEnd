create view dashboard_1_view as
select `a`.`region`                                                AS `region`,
       `a`.`province_state`                                        AS `province_state`,
       `a`.`municipality`                                          AS `municipality`,
       count(`a`.`id`)                                             AS `total_farmers`,
       sum((case when (`b`.`verified` = 1) then 1 else 0 end))     AS `total_verified`,
       sum((case when (`c`.`total_amount` > 0) then 1 else 0 end)) AS `total_cashout`
from ((`spv3plusdbp`.`user_details` `a` left join `spv3plusdbp`.`user_accounts` `b` on ((`a`.`user_account_id` = `b`.`id`)))
         left join `spv3plusdbp`.`out_disbursement_dbps` `c` on ((`a`.`user_account_id` = `c`.`user_account_id`)))
where ((`a`.`region` is not null) and (`a`.`region` <> 'NATIONAL CAPITAL REGION'))
group by `a`.`region`, `a`.`province_state`, `a`.`municipality`
order by `a`.`region`, `a`.`province_state`, `a`.`municipality`;

