create view dbp_disbursement_report_view as
select `spv3plusdbp`.`a`.`reference_number`                     AS `reference_number`,
       `spv3plusdbp`.`a`.`transaction_date`                     AS `transaction_date`,
       `spv3plusdbp`.`a`.`original_transaction_date`            AS `original_transaction_date`,
       `spv3plusdbp`.`a`.`account_number`                       AS `account_number`,
       `spv3plusdbp`.`a`.`rsbsa_number`                         AS `rsbsa_number`,
       cast(`spv3plusdbp`.`a`.`total_amount` as decimal(19, 6)) AS `total_amount`,
       `spv3plusdbp`.`a`.`first_name`                           AS `first_name`,
       `spv3plusdbp`.`a`.`middle_name`                          AS `middle_name`,
       `spv3plusdbp`.`a`.`last_name`                            AS `last_name`,
       `b`.`house_no_street`                                    AS `address`,
       `b`.`city`                                               AS `city_municipality`,
       `b`.`province_state`                                     AS `province_state`,
       `c`.`mobile_number`                                      AS `mobile_number`,
       'PHP'                                                    AS `currency`,
       NULL                                                     AS `remarks`,
       `spv3plusdbp`.`a`.`status`                               AS `status`
from ((`spv3plusdbp`.`running_balance` `a` left join `spv3plusdbp`.`user_details` `b` on ((`spv3plusdbp`.`a`.`user_account_id` = `b`.`user_account_id`)))
         left join `spv3plusdbp`.`user_accounts` `c` on ((`spv3plusdbp`.`a`.`user_account_id` = `c`.`id`)))
where (`spv3plusdbp`.`a`.`transaction_category_id` in
       ('edj4d5d0-9299-11eb-9663-1c1b0d14e211', 'edj4d5d0-9299-11eb-9663-1c1b0d14e218'));

