create view dashboard_1_finalstate_view as
select `spv3plusdbp`.`dashboard_1_view`.`region`                                                                      AS `region`,
       `spv3plusdbp`.`dashboard_1_view`.`province_state`                                                              AS `province_state`,
       `spv3plusdbp`.`dashboard_1_view`.`municipality`                                                                AS `municipality`,
       `spv3plusdbp`.`dashboard_1_view`.`total_farmers`                                                               AS `total_farmers`,
       `spv3plusdbp`.`dashboard_1_view`.`total_verified`                                                              AS `total_verified`,
       ((`spv3plusdbp`.`dashboard_1_view`.`total_verified` / `spv3plusdbp`.`dashboard_1_view`.`total_farmers`) *
        100)                                                                                                          AS `percentage_total_verified`,
       `spv3plusdbp`.`dashboard_1_view`.`total_verified`                                                              AS `total_card_issued`,
       ((`spv3plusdbp`.`dashboard_1_view`.`total_verified` / `spv3plusdbp`.`dashboard_1_view`.`total_farmers`) *
        100)                                                                                                          AS `percentage_total_card_issued`,
       `spv3plusdbp`.`dashboard_1_view`.`total_cashout`                                                               AS `total_cashout`,
       ((`spv3plusdbp`.`dashboard_1_view`.`total_cashout` / `spv3plusdbp`.`dashboard_1_view`.`total_farmers`) *
        100)                                                                                                          AS `percentage_total_cashout`
from `spv3plusdbp`.`dashboard_1_view`;

