create view dashboard_2_view as
select (select count(`spv3plusdbp`.`a`.`id`) from `spv3plusdbp`.`dbp_on_boarding_list_view_new` `a`) AS `total_farmers`,
       (select count(`spv3plusdbp`.`dbp_on_boarding_list_view_new`.`id`)
        from `spv3plusdbp`.`dbp_on_boarding_list_view_new`
        where (`spv3plusdbp`.`dbp_on_boarding_list_view_new`.`profile_status` =
               'VERIFIED'))                                                                          AS `total_verified`,
       (select count(`spv3plusdbp`.`dbp_on_boarding_list_view_new`.`id`)
        from `spv3plusdbp`.`dbp_on_boarding_list_view_new`
        where (`spv3plusdbp`.`dbp_on_boarding_list_view_new`.`profile_status` =
               'VERIFIED'))                                                                          AS `total_card_issued`,
       (select count(distinct `spv3plusdbp`.`dbp_claims_report`.`rsbsa_number`)
        from `spv3plusdbp`.`dbp_claims_report`)                                                      AS `total_cashout`;

